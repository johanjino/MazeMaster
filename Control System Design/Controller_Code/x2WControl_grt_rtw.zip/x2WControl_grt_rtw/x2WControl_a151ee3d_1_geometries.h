/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'x2WControl/Solver Configuration'.
 */

struct RuntimeDerivedValuesBundleTag;
void x2WControl_a151ee3d_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
