/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'x2WControl/Solver Configuration'.
 */

#ifndef __x2WControl_a151ee3d_1_h__
#define __x2WControl_a151ee3d_1_h__
#ifdef __cplusplus

extern "C"
{

#endif

  extern void x2WControl_a151ee3d_1_dae( NeDae **dae, const NeModelParameters
    *modelParams,
    const NeSolverParameters *solverParams);

#ifdef __cplusplus

}

#endif
#endif
